import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RmilClient{
    public static void main(String[] args) throws Exception
    {
        
     ReceiveMessageInterface rmiServer;
       Registry registry;

       String serverAddress=args[0];
       String serverPort=args[1];
       String text=args[2];
       System.out.println("sending "+text+" to "+serverAddress+":"+serverPort);
        try{
            registry=LocateRegistry.getRegistry(serverAddress,(new Integer(serverPort)).intValue());//get registry
            rmiServer=(ReceiveMessageInterface)(registry.lookup("rmiserver"));//look up (remove object)
            if (text.equals("S"))
             {
                rmiServer.Shutdown();                
            }
            else if (text.equals("R")) {
            rmiServer.Restart();                
            }
            else if (text.equals("L")) {
                rmiServer.Logoff();               
            }
            else
            rmiServer.receiveMessage(text);
        }
               catch(RemoteException e){
           e.printStackTrace();
       }
       catch(NotBoundException e){
           e.printStackTrace();
       }

    }
}