import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.net.*;
import java.lang.Runtime;
import java.util.Properties;
 
public class RmiServer extends java.rmi.server.UnicastRemoteObject implements ReceiveMessageInterface {
    
    int thisPort;
    String thisAddress;
    Registry registry;
    Runtime r = Runtime.getRuntime();
    Process p = null;
    String s = System.getProperty("os.name");

    public  void receiveMessage(String x) throws RemoteException {
        System.out.println(x);
    }

    public void Shutdown() throws RemoteException {
        System.out.println("your machinw is goring to shutdown");
        if (s.startsWith("Windows")) {
            try {
                p = r.exec("shutdown -s -f -t 00");

            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }
        }
    }

    public void Logoff() throws RemoteException {
        System.out.println("uour machine is going to log off");
        if (s.startsWith("Windows")) {
            try {
                p = r.exec("shutdown -l -f -t 00");
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }

        }
    }

    public void Restart() throws RemoteException {
        System.out.println("your machine is goinfg to restart");
        if (s.startsWith("Windows")) {
            try {
                p = r.exec("shutdown -r -f -t 00");
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }

        }
    }

    public RmiServer() throws RemoteException {
        try {
            thisAddress = (InetAddress.getLocalHost()).toString();

        } catch (Exception e) {
            // TODO: handle exception
            throw new RemoteException("cant get int address");
        }
        thisPort = 3232;
        System.out.println("this address=" + thisAddress + "port=" + thisPort);
        try {

            registry = LocateRegistry.createRegistry(thisPort);
            registry.rebind("rmiserver", this);

        } catch (Exception e) {
            throw e;
        }
    }

    public static void main(String[] args) {
        try {
            RmiServer s = new RmiServer();
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();    
        }
    }
}