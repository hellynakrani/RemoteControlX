import java.rmi.*;

public interface ReceiveMessageInterface extends Remote
{
    void receiveMessage(String x) throws RemoteException;
    void Shutdown() throws RemoteException;
    void Restart() throws RemoteException;
    void Logoff() throws RemoteException;
}