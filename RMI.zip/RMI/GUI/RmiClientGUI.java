package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class RmiClientGUI extends JFrame {
    private JTextField ipField, portField, messageField;
    private JButton connectButton, shutdownButton, restartButton, logoffButton, sendMsgButton;
    private JLabel statusLabel;

    // the remote object
    private ReceiveMessageInterface rmiServer = null;

    public RmiClientGUI() {
        super("RMI Client with GUI");
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Row 0: IP Label & Field
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Server IP:"), gbc);

        ipField = new JTextField("localhost", 10);
        gbc.gridx = 1; gbc.gridy = 0;
        add(ipField, gbc);

        // Row 1: Port Label & Field
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Port:"), gbc);

        portField = new JTextField("3232", 5);
        gbc.gridx = 1; gbc.gridy = 1;
        add(portField, gbc);

        // Row 2: Connect Button
        connectButton = new JButton("Connect");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(connectButton, gbc);

        // Row 3: Action Buttons (Shutdown, Restart, Logoff)
        JPanel buttonPanel = new JPanel(new FlowLayout());
        shutdownButton = new JButton("Shutdown");
        restartButton = new JButton("Restart");
        logoffButton = new JButton("Logoff");
        buttonPanel.add(shutdownButton);
        buttonPanel.add(restartButton);
        buttonPanel.add(logoffButton);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(buttonPanel, gbc);

        // Row 4: Custom Message Field & Button
        JPanel msgPanel = new JPanel(new FlowLayout());
        messageField = new JTextField(10);
        sendMsgButton = new JButton("Send Msg");
        msgPanel.add(messageField);
        msgPanel.add(sendMsgButton);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        add(msgPanel, gbc);

        // Row 5: Status Label
        statusLabel = new JLabel("Not connected.");
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        add(statusLabel, gbc);

        // Add ActionListeners
        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connectToServer();
            }
        });

        shutdownButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (rmiServer != null) {
                    try {
                        rmiServer.Shutdown();
                        statusLabel.setText("Shutdown command sent.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        statusLabel.setText("Error sending shutdown command.");
                    }
                } else {
                    statusLabel.setText("Not connected to server!");
                }
            }
        });

        restartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (rmiServer != null) {
                    try {
                        rmiServer.Restart();
                        statusLabel.setText("Restart command sent.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        statusLabel.setText("Error sending restart command.");
                    }
                } else {
                    statusLabel.setText("Not connected to server!");
                }
            }
        });

        logoffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (rmiServer != null) {
                    try {
                        rmiServer.Logoff();
                        statusLabel.setText("Logoff command sent.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        statusLabel.setText("Error sending logoff command.");
                    }
                } else {
                    statusLabel.setText("Not connected to server!");
                }
            }
        });

        sendMsgButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (rmiServer != null) {
                    try {
                        String msg = messageField.getText().trim();
                        if (!msg.isEmpty()) {
                            rmiServer.receiveMessage(msg);
                            statusLabel.setText("Message sent: " + msg);
                        } else {
                            statusLabel.setText("Please enter a message.");
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        statusLabel.setText("Error sending message.");
                    }
                } else {
                    statusLabel.setText("Not connected to server!");
                }
            }
        });

        // Set default close operation and window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    private void connectToServer() {
        try {
            String serverAddress = ipField.getText().trim();
            int serverPort = Integer.parseInt(portField.getText().trim());

            Registry registry = LocateRegistry.getRegistry(serverAddress, serverPort);
            rmiServer = (ReceiveMessageInterface) registry.lookup("rmiserver");

            statusLabel.setText("Connected to " + serverAddress + ":" + serverPort);
        } catch (Exception ex) {
            ex.printStackTrace();
            statusLabel.setText("Connection failed.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RmiClientGUI());
    }
}

